import UIKit
import PlaygroundSupport


struct Episode {
    var title: String
}

struct Season {
    var number: Int
    var title: String
}

// ---------------------------------------------------------------------------------------

final class SeasonCell: UITableViewCell {
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .value1, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// ===================================================================================================

final class ItemsViewController<Item, Cell: UITableViewCell>: UITableViewController {
    
    typealias configureType = (Cell, Item) -> ()
    
    var items: [Item] = []
    let reuseIdentifier = "Cell"
    var configure: (Cell, Item) -> ()
    var didSelect: (Item) -> () = { _ in }
    
    init(items: [Item], configure: (Cell, Item) -> ()) {
        self.configure = configure
        super.init(style: .plain)
        self.items = items
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        tableView.register(Cell.self, forCellReuseIdentifier: reuseIdentifier)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! Cell
        let item = items[indexPath.row]
        configure(cell, item)
        return cell
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = items[indexPath.row]
        didSelect(item)
    }
}

// ===================================================================================================

let sampleEpisodes = [
    Episode(title: "First Episode"),
    Episode(title: "Second Episode"),
    Episode(title: "Third Episode")
]

let sampleSeasons = [
    Season(number: 1, title: "Season One"),
    Season(number: 2, title: "Season Two")
]

let seasonsVC = ItemsViewController(items: sampleSeasons,
                                    configure: {cell, season in
                                        cell.textLabel?.text = "\(season.title)"
                                        cell.detailTextLabel?.text = "\(season.number)"
                                        
})

let nc = UINavigationController(rootViewController: seasonsVC)
nc.view.frame = CGRect(x: 0, y: 0, width: 320, height: 480)

seasonsVC.didSelect = { season in
    let episodesVC = ItemsViewController(items: sampleEpisodes, configure: { (cell, episode) in
        cell.textLabel?.text = episode.title
    })
    
    episodesVC.title = season.title
    nc.pushViewController(episodesVC, animated: true)
    
}

seasonsVC.title = "Seasons"

PlaygroundPage.current.liveView = nc.view

